var File = function() {
  
  return {
    render : function() {
      return (
        'File'
      )
    }
  };
}