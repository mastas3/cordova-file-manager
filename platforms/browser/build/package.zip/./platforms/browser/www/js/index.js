document.addEventListener('deviceready', function() {
    fileManager.init(cordova.file.applicationStorageDirectory);
}, false)




