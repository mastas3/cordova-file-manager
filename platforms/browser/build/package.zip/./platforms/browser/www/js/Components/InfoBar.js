var InfoBar = function() {
  
}